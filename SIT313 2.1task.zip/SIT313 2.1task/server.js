const express = require('express');
const bodyParser = require('body-parser');
const app = express();

const sendGridMail = require('@sendgrid/mail');
process.env.SENDGRID_API_KEY = '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'

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.get('/', (request, response) => {
  response.sendFile(__dirname + '/index.html');
});

app.post('/', (request, response) => {
  const email = request.body.email;
  const message = {
    to: email,
    from: 'wangshuyu@deakin.edu.au',
    subject: 'Welcome!',
    html: '<strong>Message sent by sendgrid!</strong>',
    text: 'Test message from SendGrid',
  };
  require('dotenv').config();
  sendGridMail.setApiKey(process.env.SENDGRID_API_KEY);

  sendGridMail.send(message).then(() => {
    console.log('Email sent successfully');
  });

  response.send("'Email sent successfully'");
});

app.listen(8000, function (request, response) {
  console.log('server is running');
});
